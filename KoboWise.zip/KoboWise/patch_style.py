import re

with open('assets/css/style.css', 'r') as f:
    content = f.read()

# 1. Variables
content = content.replace(''':root {
    --bg-dark: #0f172a;       /* Slate 900 */
    --card-bg: #1e293b;       /* Slate 800 */
    --card-hover: #334155;    /* Slate 700 */
    --primary: #f59e0b;       /* Amber 500 */
    --primary-glow: rgba(245, 158, 11, 0.4);
    --secondary: #0ea5e9;     /* Sky 500 */
    --accent: #10b981;        /* Emerald 500 */
    --danger: #ef4444;        /* Red 500 */
    --text-white: #f8fafc;
    --text-gray: #94a3b8;
    --border-color: rgba(255,255,255,0.08);
}''', ''':root {
    --bg-main: #f8fafc;
    --card-bg: #ffffff;
    --card-hover: #f1f5f9;
    --primary: #7B1FA2;       /* Améthyste */
    --primary-glow: rgba(123, 31, 162, 0.4);
    --secondary: #4A154B;     /* Prune Profond */
    --accent: #2ECC71;        /* Vert Émeraude */
    --danger: #ef4444;
    --text-main: #2D2D2D;     /* Noir de Carbone */
    --text-gray: #64748b;
    --border-color: rgba(0,0,0,0.08);
}''')

# 2. Body
content = content.replace('background-color: var(--bg-dark);', 'background-color: var(--bg-main);')
content = content.replace('color: var(--text-white);', 'color: var(--text-main);')

# 3. Header
content = content.replace('background: rgba(30, 41, 59, 0.8);', 'background: rgba(255, 255, 255, 0.9);')

# 4. Logo span
content = content.replace('''
.logo span {
    color: var(--primary);
}''', '''
.logo span {
    color: var(--text-main);
}''')

# 5. User profile avatar
content = content.replace('''
    background: linear-gradient(135deg, var(--primary), #d97706);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.1rem;
    color: #fff;
    box-shadow: 0 4px 12px var(--primary-glow);
''', '''
    background: var(--accent);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.1rem;
    color: #fff;
    box-shadow: 0 4px 12px rgba(46, 204, 113, 0.4);
''')

# 6. Trust Card
content = content.replace('background: linear-gradient(145deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.01) 100%);', 'background: #ffffff;')

content = content.replace('''
    background: var(--secondary);
    filter: blur(50px);
    opacity: 0.3;
''', '''
    background: var(--primary);
    filter: blur(50px);
    opacity: 0.1;
''')

content = content.replace('''
.card-header h2 {
    font-size: 1rem;
    font-weight: 500;
    color: var(--text-gray);
}
''', '''
.card-header h2 {
    font-size: 1rem;
    font-weight: 600;
    color: var(--secondary);
}
''')

content = content.replace('''
.score-display .score {
    font-size: 3.5rem;
    font-weight: 800;
    color: var(--text-white);
    line-height: 1;
}
''', '''
.score-display .score {
    font-size: 3.5rem;
    font-weight: 800;
    color: var(--secondary);
    line-height: 1;
}
''')

content = content.replace('''
.progress-bar {
    width: 100%;
    height: 8px;
    background: rgba(255,255,255,0.1);
''', '''
.progress-bar {
    width: 100%;
    height: 8px;
    background: rgba(0,0,0,0.05);
''')

content = content.replace('''
    background: linear-gradient(90deg, var(--secondary), var(--accent));
''', '''
    background: linear-gradient(90deg, #9C27B0, var(--primary));
''')

content = content.replace('''
.trust-metric-info i {
    color: var(--secondary);
}
''', '''
.trust-metric-info i {
    color: var(--accent);
}
''')

content = content.replace('''
.section-title {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 16px;
    color: var(--text-white);
}
''', '''
.section-title {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 16px;
    color: var(--secondary);
}
''')

content = content.replace('''
    background: rgba(255,255,255,0.03);
''', '''
    background: #ffffff;
''')

content = content.replace('''
    background: rgba(255,255,255,0.06);
''', '''
    background: var(--card-hover);
''')

content = content.replace('''
.tx-amount.negative {
    color: var(--text-white);
}
''', '''
.tx-amount.negative {
    color: var(--text-main);
}
''')

content = content.replace('''
.text-input-section {
    background: rgba(255,255,255,0.03);
''', '''
.text-input-section {
    background: #ffffff;
''')

content = content.replace('''
.input-group input {
    flex: 1;
    background: rgba(0,0,0,0.2);
    border: 1px solid var(--border-color);
    padding: 12px 16px;
    border-radius: 12px;
    color: var(--text-white);
    font-size: 1rem;
    outline: none;
}
''', '''
.input-group input {
    flex: 1;
    background: #f1f5f9;
    border: 1px solid var(--border-color);
    padding: 12px 16px;
    border-radius: 12px;
    color: var(--text-main);
    font-size: 1rem;
    outline: none;
}
''')

content = content.replace('''
.btn-send:hover {
    background: #d97706;
}
''', '''
.btn-send:hover {
    background: var(--secondary);
}
''')

content = content.replace('''
    background: linear-gradient(to top, var(--card-bg) 60%, transparent);
''', '''
    background: linear-gradient(to top, var(--bg-main) 40%, transparent);
''')

content = content.replace('''
.action-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: rgba(255,255,255,0.05);
''', '''
.action-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: #ffffff;
''')

content = content.replace('''
.action-btn:hover {
    background: rgba(255,255,255,0.1);
    color: var(--text-white);
}
''', '''
.action-btn:hover {
    background: var(--card-hover);
    color: var(--primary);
}
''')

content = content.replace('''
    background: linear-gradient(135deg, var(--primary), #ea580c);
''', '''
    background: linear-gradient(135deg, var(--primary), var(--secondary));
''')

content = content.replace('''
.loading-overlay {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(15, 23, 42, 0.8);
    backdrop-filter: blur(5px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 100;
    color: white;
    font-weight: 600;
    display: none;
}
''', '''
.loading-overlay {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(5px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 100;
    color: var(--text-main);
    font-weight: 600;
    display: none;
}
''')

content = content.replace('''
    border: 4px solid rgba(255,255,255,0.1);
''', '''
    border: 4px solid rgba(0,0,0,0.1);
''')


with open('assets/css/style.css', 'w') as f:
    f.write(content)

print("Migration done")
