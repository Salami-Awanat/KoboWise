document.addEventListener('DOMContentLoaded', () => {
    
    // --- UI Elements ---
    const btnMic = document.getElementById('btnMic');
    const helperText = document.getElementById('voiceHelperText');
    const transactionList = document.getElementById('transactionList');
    const scoreValue = document.getElementById('scoreValue');
    const scoreProgress = document.getElementById('scoreProgress');
    const savingsTotal = document.getElementById('savingsTotal');
    const loadingOverlay = document.getElementById('loadingOverlay');
    
    // Text Mode Elements
    const btnKeyboard = document.getElementById('btnKeyboard');
    const textInputSection = document.getElementById('textInputSection');
    const btnSendText = document.getElementById('btnSendText');
    const textTransaction = document.getElementById('textTransaction');

    let isRecording = false;
    let recognition;

    // --- Web Speech API Setup ---
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
        recognition = new SpeechRecognition();
        recognition.lang = 'fr-CI'; // Adapté à la cible ivoirienne
        recognition.continuous = false; // Arrête après une phrase
        recognition.interimResults = true; // Afficher pendant qu'on parle
        
        recognition.onstart = () => {
            isRecording = true;
            btnMic.classList.add('recording');
            helperText.innerText = "Je vous écoute, parlez...";
            helperText.style.color = "var(--primary)";
        };
        
        recognition.onresult = (event) => {
            let finalTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    finalTranscript += event.results[i][0].transcript;
                } else {
                    helperText.innerText = `"${event.results[i][0].transcript}..."`;
                }
            }
            
            if (finalTranscript) {
                helperText.innerText = `Traitement : "${finalTranscript}"`;
                sendTransactionToCoreEngine(finalTranscript, 'VOCAL');
            }
        };
        
        recognition.onerror = (event) => {
            console.error('Erreur vocale', event.error);
            helperText.innerText = "Erreur: " + event.error + ". Essayez le mode texte.";
            btnMic.classList.remove('recording');
            isRecording = false;
        };
        
        recognition.onend = () => {
            btnMic.classList.remove('recording');
            isRecording = false;
            setTimeout(() => {
                if(!isRecording) helperText.innerText = "Appuyez sur le micro et parlez";
                helperText.style.color = "var(--text-gray)";
            }, 3000);
        };
    } else {
        helperText.innerText = "Mode vocal non supporté. Veuillez utiliser le texte.";
        btnMic.style.opacity = '0.5';
        btnMic.disabled = true;
    }

    // --- Event Listeners ---
    btnMic.addEventListener('click', () => {
        if (!SpeechRecognition) return;
        
        if (isRecording) {
            recognition.stop();
        } else {
            recognition.start();
        }
    });

    // Toggle Text Mode
    btnKeyboard.addEventListener('click', () => {
        textInputSection.classList.toggle('active');
        if(textInputSection.classList.contains('active')) {
            textTransaction.focus();
        }
    });

    // Send Text Transaction
    const submitText = () => {
        const textStr = textTransaction.value.trim();
        if(textStr) {
            sendTransactionToCoreEngine(textStr, 'TEXTE');
            textTransaction.value = '';
            textInputSection.classList.remove('active');
        }
    };
    
    btnSendText.addEventListener('click', submitText);
    textTransaction.addEventListener('keypress', (e) => {
        if(e.key === 'Enter') submitText();
    });

    // --- Core Engine Integration ---
    async function sendTransactionToCoreEngine(text, method) {
        loadingOverlay.classList.add('active');
        
        try {
            const response = await fetch('api/process_transaction.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text, method })
            });
            
            const data = await response.json();
            
            // Artificial delay to show AI processing in demo
            setTimeout(() => {
                loadingOverlay.classList.remove('active');
                
                if (data.success) {
                    // Feedback audio (Optional logic)
                    speakResponse(data.message);
                    
                    // Update UI immediately (DOM Manipulation)
                    updateScoreUI(data.new_score, data.new_savings);
                    addNewTransactionUI(data.transaction);
                } else {
                    alert('Assistant KoboWise : ' + data.message);
                }
            }, 800);
            
        } catch (error) {
            console.error(error);
            loadingOverlay.classList.remove('active');
            alert('Erreur de connexion au serveur.');
        }
    }

    // --- UI Update Helpers ---
    function updateScoreUI(newScore, newSavings) {
        // Animate count up logic could be here, simply updating HTML for now:
        scoreValue.innerText = Math.round(newScore);
        scoreProgress.style.width = newScore + '%';
        
        // Format Currency
        const formatter = new Intl.NumberFormat('fr-CI', { 
            style: 'currency', currency: 'XOF', maximumFractionDigits: 0
        });
        
        savingsTotal.innerText = `Épargne tracée : ${formatter.format(newSavings).replace('XOF', 'FCFA')}`;
        
        // Update styling based on threshold
        if (newScore > 75) {
            document.getElementById('scoreStatus').innerText = "ELIGIBLE PRET";
            document.getElementById('scoreStatus').style.color = "#10b981";
            document.getElementById('scoreStatus').style.background = "rgba(16, 185, 129, 0.2)";
        }
    }

    function addNewTransactionUI(tx) {
        let iconClass = 'fa-arrow-trend-up';
        let typeClass = 'income';
        let txSign = '+';
        let amountClass = 'positive';
        
        if (tx.type === 'DEPENSE') {
            iconClass = 'fa-arrow-trend-down';
            typeClass = 'expense';
            txSign = '-';
            amountClass = 'negative';
        } else if (tx.type === 'TONTINE') {
            iconClass = 'fa-users';
            typeClass = 'tontine';
        }
        
        const formatter = new Intl.NumberFormat('fr-CI', { maximumFractionDigits: 0 });
        const formatAmount = formatter.format(tx.amount);
        
        const txHTML = `
            <div class="transaction-item new-item-anim">
                <div class="tx-icon ${typeClass}">
                    <i class="fa-solid ${iconClass}"></i>
                </div>
                <div class="tx-details">
                    <div class="tx-title">${tx.category}</div>
                    <div class="tx-date">${tx.date}</div>
                </div>
                <div class="tx-amount ${amountClass}">
                    ${txSign}${formatAmount} F
                </div>
            </div>
        `;
        
        // Insert at the top
        transactionList.insertAdjacentHTML('afterbegin', txHTML);
        
        // Keep ONLY max 5 items in demo
        if (transactionList.children.length > 5) {
            transactionList.removeChild(transactionList.lastElementChild);
        }
    }

    // --- Text-to-Speech Companion ---
    function speakResponse(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'fr-CI';
            utterance.pitch = 1.1; // Friendly voice
            utterance.rate = 1.0;
            window.speechSynthesis.speak(utterance);
        }
    }
});
