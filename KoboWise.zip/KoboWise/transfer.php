<?php
// transfer.php : Send Money Details / Chat Screen
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>KoboWise - Transfert</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="app-container">
    <div class="transfer-header">
        <button class="back-btn" onclick="window.location.href='index.php'"><i class="fa-solid fa-arrow-left"></i></button>
        <div class="transfer-user-info">
            <div class="avatar">
                <i class="fa-solid fa-user-astronaut"></i>
                <div class="status-dot"></div>
            </div>
            <h2>Kristin Watson</h2>
        </div>
        <button class="back-btn"><i class="fa-solid fa-ellipsis-vertical"></i></button>
    </div>

    <div class="transfer-amount-section">
        <input type="text" class="amount-input" value="₹ 3,470" readonly>
        <div class="status">Received</div>
    </div>

    <!-- Big Decorative Logo placeholder -->
    <div class="logo-overlay">
        <!-- SVG graphic that looks like the multi-colored bar chart -->
        <i class="fa-solid fa-chart-simple" style="font-size: 15rem; color: var(--primary);"></i>
    </div>

    <div class="chat-history">
        <!-- Received chat bubble -->
        <div class="chat-bubble received">
            <div class="chat-amount">₹ 3,470</div>
            <div class="chat-date">Aug 15, 2023 at 10:24 AM</div>
        </div>
        
        <!-- Sent chat bubble (mockup format) -->
        <div class="chat-bubble sent" style="margin-top: 50px;">
            <div class="chat-amount">₹ 1,500</div>
            <div class="chat-date" style="color: rgba(255,255,255,0.7);">Aug 10, 2023 at 9:00 AM</div>
        </div>
        
        <form style="margin-top:20px;" action="success.php" method="POST">
             <button type="submit" class="action-btn-large">Pay Now</button>
        </form>
    </div>

    <nav class="bottom-nav">
        <a href="index.php" class="nav-item"><i class="fa-solid fa-house"></i></a>
        <a href="#" class="nav-item"><i class="fa-solid fa-wallet"></i></a>
        
        <div class="nav-fab-wrapper">
            <button class="nav-fab" style="background: var(--bg-soft); color: var(--primary);">
                <i class="fa-solid fa-wallet"></i>
            </button>
        </div>
        
        <a href="#" class="nav-item"><i class="fa-solid fa-gear"></i></a>
        <a href="#" class="nav-item active"><i class="fa-solid fa-arrow-right-arrow-left"></i></a>
    </nav>
</div>

</body>
</html>
