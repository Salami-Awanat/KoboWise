<?php
// Initialisation de la base de données SQLite pour le projet KoboWise
$dbFile = __DIR__ . '/../kobowise.sqlite';
$dsn = 'sqlite:' . $dbFile;
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, null, null, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Création des tables si elles n'existent pas
$pdo->exec("
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    user_type TEXT DEFAULT 'COMMERCANTE',
    language TEXT DEFAULT 'fr-CI',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    category TEXT NOT NULL,
    transaction_type TEXT DEFAULT 'DEPENSE',
    input_method TEXT DEFAULT 'VOCAL',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS trust_score (
    user_id INTEGER PRIMARY KEY,
    reliability_ratio REAL DEFAULT 0.00,
    total_savings REAL DEFAULT 0.00,
    consecutive_saving_days INTEGER DEFAULT 0,
    status TEXT DEFAULT 'EN_COURS',
    FOREIGN KEY (user_id) REFERENCES users(id)
);
");

// Insertion d'un utilisateur par défaut si vide (Mme Koné pour la démo)
$stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
$row = $stmt->fetch();
if ($row['count'] == 0) {
    $pdo->exec("INSERT INTO users (full_name, user_type) VALUES ('Mme Koné (Démo)', 'COMMERCANTE')");
    $pdo->exec("INSERT INTO trust_score (user_id, reliability_ratio, total_savings, status) VALUES (1, 65.00, 15000, 'EN_COURS')");
    
    // Quelques transactions de démo
    $pdo->exec("INSERT INTO transactions (user_id, amount, category, transaction_type) VALUES (1, 5000, 'Tontine', 'TONTINE')");
    $pdo->exec("INSERT INTO transactions (user_id, amount, category, transaction_type) VALUES (1, 2000, 'Marchandise', 'DEPENSE')");
}
?>
