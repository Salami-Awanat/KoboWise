<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_contents('php://input'), true);
if (!$input && isset($_POST['text'])) {
    $input = $_POST;
}

$text = $input['text'] ?? '';
$method = $input['method'] ?? 'VOCAL'; // VOCAL ou TEXTE
$userId = 1; // User de démo

if (empty($text)) {
    echo json_encode(['success' => false, 'message' => 'Texte vide']);
    exit;
}

/**
 * Moteur d'Analyse Séantique Simplifié (NLP maison)
 * Détecte les intentions d'épargne, de dépense ou de tontine.
 */
// Normaliser
$textLower = strtolower(trim($text));

// Patterns pour détecter le montant
preg_match('/(\d+)\s*(?:francs?|f|fcfa)/i', $textLower, $amountMatches);
if (empty($amountMatches)) {
    preg_match('/(\d+)/', $textLower, $amountMatches);
}
$amount = !empty($amountMatches[1]) ? (float)$amountMatches[1] : 0;

if ($amount == 0) {
    echo json_encode(['success' => false, 'message' => 'Aucun montant détecté. Dites par exemple: "J\'ai dépensé 2000 francs en nourriture".']);
    exit;
}

// Analyser l'intention (Dépense, Épargne, Tontine)
$type = 'DEPENSE';
if (strpos($textLower, 'épargné') !== false || strpos($textLower, 'economisé') !== false || strpos($textLower, 'gardé') !== false) {
    $type = 'EPARGNE';
} elseif (strpos($textLower, 'tontine') !== false) {
    $type = 'TONTINE';
}

// Analyser la catégorie (rudimentaire)
$category = 'Autre';
if (preg_match('/(?:en|pour)\s+([a-zàâéèêôùûç\s]+)/i', $textLower, $catMatches)) {
    $category = ucfirst(trim($catMatches[1]));
} elseif ($type === 'TONTINE') {
    $category = 'Cotisation Tontine';
}

// Insérer la transaction
$stmt = $pdo->prepare("INSERT INTO transactions (user_id, amount, category, transaction_type, input_method) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([$userId, $amount, $category, $type, $method]);
$transactionId = $pdo->lastInsertId();

// Mettre à jour le Core Engine (Score de Fiabilité)
$stmt = $pdo->prepare("SELECT * FROM trust_score WHERE user_id = ?");
$stmt->execute([$userId]);
$score = $stmt->fetch();

$newScore = (float)$score['reliability_ratio'];
$newSavings = (float)$score['total_savings'];

if ($type === 'TONTINE' || $type === 'EPARGNE') {
    $newScore += ($amount / 1000) * 0.5; // +0.5 pts pour chaque 1000f épargné
    $newSavings += $amount;
} else if ($type === 'DEPENSE') {
    // Les dépenses ne réduisent pas nécessairement le score de confiance bancaire, 
    // mais elles montrent de l'activité. On ajoute un micro-bonus pour l'utilisation.
    $newScore += 0.1; 
}

// Capper le score
if ($newScore > 100) $newScore = 100;

// Mise à jour de la base de données
$stmt = $pdo->prepare("UPDATE trust_score SET reliability_ratio = ?, total_savings = ? WHERE user_id = ?");
$stmt->execute([$newScore, $newSavings, $userId]);

// Récupérer la data formatée
echo json_encode([
    'success' => true,
    'message' => "Transaction de {$amount}F enregistrée.",
    'transaction' => [
        'id' => $transactionId,
        'amount' => $amount,
        'category' => $category,
        'type' => $type,
        'date' => date('d M Y à H:i'),
        'method' => $method
    ],
    'new_score' => $newScore,
    'new_savings' => $newSavings
]);
