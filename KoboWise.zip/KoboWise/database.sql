CREATE DATABASE IF NOT EXISTS kobowise_db;
USE kobowise_db;

-- Table des utilisateurs (Les femmes commerçantes, les étudiants, etc.)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) UNIQUE NOT NULL,
    user_type ENUM('COMMERCANTE', 'ETUDIANT', 'AUTRE') DEFAULT 'COMMERCANTE',
    preferred_language VARCHAR(50) DEFAULT 'fr-CI',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des transactions (Dépenses, Épargne, Tontine, gérées par le Voice/Text Input)
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL, -- e.g., 'nourriture', 'transport', 'stock'
    transaction_type ENUM('DEPENSE', 'EPARGNE', 'TONTINE') DEFAULT 'DEPENSE',
    input_method ENUM('VOCAL', 'TEXTE', 'USSD') DEFAULT 'VOCAL',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Le Core Engine : Table de Scoring Bancaire (Le Pont de Confiance Digitale)
CREATE TABLE IF NOT EXISTS trust_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE NOT NULL,
    reliability_ratio DECIMAL(5, 2) DEFAULT 0.00, -- Score sur 100
    total_savings DECIMAL(12, 2) DEFAULT 0.00,
    consecutive_saving_days INT DEFAULT 0,
    missed_tontine_payments INT DEFAULT 0,
    status ENUM('NON_ELIGIBLE', 'EN_COURS', 'PRET_BANCAIRE_VALIDE') DEFAULT 'NON_ELIGIBLE',
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Groupes de Tontine 
CREATE TABLE IF NOT EXISTS tontine_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_name VARCHAR(100) NOT NULL,
    contribution_amount DECIMAL(10, 2) NOT NULL,
    cycle_days INT DEFAULT 7, -- Ex: Hebdomadaire
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Historique de la tontine
CREATE TABLE IF NOT EXISTS tontine_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    user_id INT NOT NULL,
    amount_paid DECIMAL(10,2) NOT NULL,
    paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_on_time BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (group_id) REFERENCES tontine_groups(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
