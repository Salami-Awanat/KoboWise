<?php
// success.php : Payment Successful Status
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>KoboWise - Success</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="app-container success-mode">
    <div class="app-header">
        <!-- Transparent header -->
        <div style="width: 100%; display: flex; justify-content: flex-end;">
            <div style="color: white; font-size: 1.2rem;">9:41</div>
        </div>
    </div>

    <div class="success-content">
        <div class="success-icon-large">
            <i class="fa-solid fa-check"></i>
        </div>
        
        <div class="success-title">
            Payment<br>Successful
        </div>
        
        <div class="success-user-pill">
            <div class="avatar">
                <i class="fa-solid fa-user-astronaut"></i>
                <div class="status-dot"></div>
            </div>
            <span>Kristin Watson</span>
        </div>
    </div>

    <!-- Bottom Navigation specific for success screen -->
    <nav class="bottom-nav transparent" style="justify-content: center; margin-bottom: 20px;">
        <a href="index.php" class="nav-item active" style="font-size: 2rem;">
            <i class="fa-solid fa-house"></i>
        </a>
    </nav>
</div>

<!-- Auto redirect to home after 3 seconds -->
<script>
    setTimeout(() => {
        window.location.href = 'index.php';
    }, 4000);
</script>

</body>
</html>
