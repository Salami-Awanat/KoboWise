<?php
// index.php : Home / Dashboard
require_once __DIR__ . '/api/db.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>KoboWise - Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="app-container">
    <!-- Header -->
    <header class="app-header">
        <h1 class="header-title">Send Money</h1>
        <div class="header-actions">
            <button class="search-btn"><i class="fa-solid fa-magnifying-glass"></i></button>
            <div class="profile-avatar">
                <i class="fa-solid fa-user"></i>
                <div class="status-dot"></div>
            </div>
        </div>
    </header>

    <main class="app-content">
        <!-- Saved Payment Method -->
        <h2 class="section-title">Saved Payment Method</h2>
        <div class="h-scroll">
            <div class="payment-card light">
                <div class="card-logo">
                    <i class="fa-solid fa-building-columns" style="color: #0ea5e9;"></i> State Bank
                </div>
                <div style="font-size: 1.2rem; font-weight: 600;">UPI</div>
            </div>
            <div class="payment-card primary">
                <div class="card-logo">
                    <i class="fa-brands fa-cc-mastercard" style="font-size: 1.2rem;"></i> Mastercard
                </div>
                <div style="font-size: 1.1rem; font-weight: 600;">**** 4893</div>
            </div>
        </div>

        <!-- Frequent -->
        <h2 class="section-title">Frequent</h2>
        <div class="h-scroll">
            <a href="transfer.php" style="text-decoration: none;">
                <div class="frequent-user">
                    <div class="avatar-wrapper">
                        <i class="fa-solid fa-user-astronaut"></i>
                        <div class="status-dot-small"></div>
                    </div>
                    <span class="name">Kristin<br>Watson</span>
                </div>
            </a>
            <div class="frequent-user">
                <div class="avatar-wrapper">
                    <i class="fa-solid fa-user-ninja"></i>
                    <div class="status-dot-small"></div>
                </div>
                <span class="name">Dianne<br>Russell</span>
            </div>
            <div class="frequent-user">
                <div class="avatar-wrapper">
                    <i class="fa-solid fa-user-tie"></i>
                </div>
                <span class="name">Albert<br>Flores</span>
            </div>
            <div class="frequent-user">
                <div class="avatar-wrapper">
                    <i class="fa-solid fa-user-graduate"></i>
                </div>
                <span class="name">Cody<br>Fisher</span>
            </div>
        </div>

        <!-- Recents -->
        <h2 class="section-title">Recents</h2>
        <div class="transaction-list">
            <div class="transaction-item">
                <div class="tx-icon-wrapper spotify">
                    <i class="fa-brands fa-spotify"></i>
                </div>
                <div class="tx-info">
                    <div class="tx-name">Spotify</div>
                    <div class="tx-date">July 25 - 8:30AM</div>
                </div>
                <div class="tx-amount negative">- ₹299</div>
            </div>
            
            <div class="transaction-item">
                <div class="tx-icon-wrapper netflix">
                    <i class="fa-solid fa-n" style="font-weight: 900;"></i>
                </div>
                <div class="tx-info">
                    <div class="tx-name">Netflix</div>
                    <div class="tx-date">July 20 - 10:00PM</div>
                </div>
                <div class="tx-amount negative">- ₹799</div>
            </div>

            <a href="transfer.php" style="text-decoration: none; color: inherit;">
                <div class="transaction-item">
                    <div class="tx-icon-wrapper user">
                        <i class="fa-solid fa-user-astronaut"></i>
                    </div>
                    <div class="tx-info">
                        <div class="tx-name">Kristin Watson</div>
                        <div class="tx-date">July 18 - 5:00AM</div>
                    </div>
                    <div class="tx-amount positive">+ ₹500</div>
                </div>
            </a>
            
            <div class="transaction-item">
                <div class="tx-icon-wrapper user">
                    <i class="fa-solid fa-user-tie"></i>
                </div>
                <div class="tx-info">
                    <div class="tx-name">Albert Flores</div>
                    <div class="tx-date">July 15 - 2:00PM</div>
                </div>
                <div class="tx-amount positive">+ ₹1500</div>
            </div>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <nav class="bottom-nav">
        <a href="index.php" class="nav-item active"><i class="fa-solid fa-house"></i></a>
        <a href="#" class="nav-item"><i class="fa-solid fa-wallet"></i></a>
        
        <div class="nav-fab-wrapper">
            <button class="nav-fab" onclick="window.location.href='transfer.php'">
                <i class="fa-solid fa-qrcode"></i>
            </button>
        </div>
        
        <a href="#" class="nav-item"><i class="fa-solid fa-gear"></i></a>
        <a href="#" class="nav-item"><i class="fa-solid fa-arrow-right-arrow-left"></i></a>
    </nav>
</div>

</body>
</html>
